# Remote AC (Panasonic LN9AKJ)

Remote AC lewat IR blaster HP. Kotlin, minSdk 26, tanpa internet.

## Build
- Android Studio: File > Open folder ini > Run.
- Terminal (butuh Android SDK): `./gradlew assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`
- Tes unit: `./gradlew testDebugUnitTest`

## Tes di AC
1. Arahkan IR blaster (sisi atas HP) ke AC, jarak dekat.
2. Tekan NYALAKAN. Jika AC diam, tekan lama angka suhu untuk ganti carrier 36,7 <-> 38 kHz.
3. Jika tetap diam, kabari byte yang perlu disesuaikan.

## Catatan
- Remote tidak tahu status asli AC. Jika AC dinyalakan dengan remote asli, status di app bisa berbeda; tekan "Kirim ulang".
- Timer pakai AlarmManager. Alarm tepat waktu jika izin "Alarm & pengingat" aktif (Android 12+), jika tidak bisa meleset beberapa menit. Timer dan preset Tidur/Cepat otomatis dipasang ulang setelah HP restart.
- Memasang timer baru atau preset baru selalu membatalkan semua alarm lama.
- Ganti merek AC: ganti `PanasonicAc.kt` (encoder), UI tetap.

## Preset
Prinsip: suhu setelan 26° + kipas sedang terasa hampir sama sejuk dengan 24° kipas pelan, tapi lebih hemat (tiap 1° lebih tinggi kira-kira 3-5% listrik). Suhu 16-18° lama-lama membuat kompresor bekerja maksimal dan boros.
- Hemat: Cool 26°, kipas sedang (Fan 3), swing.
- Powerful: Cool 16°, kipas maksimal (preset software, bukan tombol POWERFUL asli remote). Pakai sebentar saja.
- Tidur: Cool 25°, kipas pelan, naik 1° pada jam ke-1 dan ke-2 (sampai 27°), mati setelah 7 jam.
- Kering: Dry 26° (menurunkan kelembapan, cocok saat lembap tapi tidak panas).
- Angin: kipas saja (kompresor mati, paling hemat).
- Cepat lalu Hemat: Cool 20° kipas maksimal 15 menit, lalu otomatis pindah ke Hemat (26°, Fan 3).
Rasa dingin itu subjektif; jika kurang sejuk, turunkan 1° dari dial. Perkiraan hematnya bisa dilihat di menu Pengaturan.

## Perkiraan listrik
Aplikasi mencatat lama AC menyala dari tombol di app/widget/timer (tidak tahu kalau dinyalakan dari remote asli).
kWh = jam x watt/1000 x faktor kompresor. Default: 760 W (CS-LN9AKJ), Rp1.444,70/kWh (R-1/TR 2200 VA), faktor 70%.

## Tampilan
Gaya biru kaca: dial suhu melingkar (geser busur), kartu Preset/Mode/Kipas. Perkiraan listrik dan carrier IR ada di menu gear (Pengaturan). Tema selalu terang.

## Quick Settings
Tarik panel notifikasi > ikon pensil > tambahkan tile "Remote AC". Ketuk untuk nyalakan/matikan AC dengan setelan terakhir.

## Token listrik
Menu Pengaturan > "Token listrik". Isi sisa token di meter (kWh) dan perkiraan pemakaian rumah selain AC per hari. App menghitung:
sisa = saldo - (pemakaian rumah lain x hari berlalu) - (pemakaian AC tercatat sejak saldo dicatat).
Perkiraan hari sisa memakai rata-rata AC 7 hari terakhir + pemakaian rumah lain. Sisa token dan peringatan (merah, bila sisa kurang dari batas hari) tampil di layar utama.
Perbarui angka ini tiap cek meter atau beli token. Ini perkiraan; pemakaian AC dari remote asli tidak tercatat.

### Notifikasi token
Setiap hari sekitar jam 09:00 app memeriksa perkiraan; bila sisa hari <= batas peringatan, muncul notifikasi (maksimal sekali sehari). Android 13+ meminta izin notifikasi saat Anda menyimpan saldo token. Cek harian dipasang ulang setelah HP restart dan saat app dibuka. Alarm ini inexact (bisa meleset beberapa menit) dan terpisah dari alarm timer/preset, jadi tidak ikut terhapus saat Anda memasang timer baru.

## Cadangan data
Pengaturan > "Cadangkan data". "Salin / kirim data" menyalin teks cadangan (dan membuka menu kirim); "Pulihkan dari clipboard" memasukkannya kembali setelah pasang ulang. Isi: riwayat pemakaian AC, saldo token, pengaturan listrik, setelan terakhir. Status sesaat (AC sedang menyala, timer) tidak ikut. Data tidak hilang jika APK baru bisa menimpa app lama (tanda tangan sama); cadangan ini untuk saat harus uninstall dulu.
