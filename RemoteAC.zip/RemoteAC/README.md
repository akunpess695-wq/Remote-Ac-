# Remote AC (Panasonic LN9AKJ)

Remote AC lewat IR blaster HP. Kotlin, minSdk 26, tanpa internet.

## Build
- Android Studio: File > Open folder ini > Run.
- Terminal (butuh Android SDK): `./gradlew assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`
- Tes unit: `./gradlew testDebugUnitTest`

## Tes di AC
1. Arahkan IR blaster (sisi atas HP) ke AC, jarak dekat.
2. Tekan NYALAKAN. Jika AC diam, tekan lama angka suhu untuk ganti carrier 36,7 <-> 38 kHz.
3. Jika tetap diam, kabari byte yang perlu disesuaikan.

## Catatan
- Remote tidak tahu status asli AC. Jika AC dinyalakan dengan remote asli, status di app bisa berbeda; tekan "Kirim ulang".
- Timer pakai AlarmManager (tidak tepat ke detik, hilang jika HP restart).
- Ganti merek AC: ganti `PanasonicAc.kt` (encoder), UI tetap.
