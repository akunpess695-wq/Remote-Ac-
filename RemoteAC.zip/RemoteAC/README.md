# Remote AC (Panasonic LN9AKJ)

Remote AC lewat IR blaster HP. Kotlin, minSdk 26, tanpa internet.

## Build
- Android Studio: File > Open folder ini > Run.
- Terminal (butuh Android SDK): `./gradlew assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`
- Tes unit: `./gradlew testDebugUnitTest`

## Tes di AC
1. Arahkan IR blaster (sisi atas HP) ke AC, jarak dekat.
2. Tekan NYALAKAN. Jika AC diam, tekan lama angka suhu untuk ganti carrier 36,7 <-> 38 kHz.
3. Jika tetap diam, kabari byte yang perlu disesuaikan.

## Catatan
- Remote tidak tahu status asli AC. Jika AC dinyalakan dengan remote asli, status di app bisa berbeda; tekan "Kirim ulang".
- Timer pakai AlarmManager (tidak tepat ke detik, hilang jika HP restart).
- Ganti merek AC: ganti `PanasonicAc.kt` (encoder), UI tetap.

## Preset
- Hemat: Cool 25°, kipas Auto, swing.
- Powerful: Cool 16°, kipas maksimal (preset software, bukan tombol POWERFUL asli remote).
- Tidur: Cool 24°, kipas pelan, naik 1° tiap jam (sampai 27°), mati setelah 7 jam.
- Kering: Dry 25°. Angin: kipas saja (kompresor mati, paling hemat).
- Cepat lalu Hemat: Powerful 15 menit, lalu otomatis pindah ke Hemat (25°).

## Perkiraan listrik
Aplikasi mencatat lama AC menyala dari tombol di app/widget/timer (tidak tahu kalau dinyalakan dari remote asli).
kWh = jam x watt/1000 x faktor kompresor. Default: 760 W (CS-LN9AKJ), Rp1.444,70/kWh (R-1/TR 2200 VA), faktor 70%.
