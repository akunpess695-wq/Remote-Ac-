package com.example.remoteac

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AlarmCodecTest {
    @Test fun roundtrip() {
        val l = listOf(
            AlarmSpec(11, 1_000L, delta = 1),
            AlarmSpec(14, 2_000L),
            AlarmSpec(15, 3_000L, hemat = true)
        )
        assertEquals(l, AlarmCodec.decode(AlarmCodec.encode(l)))
    }

    @Test fun empty_and_garbage() {
        assertTrue(AlarmCodec.decode(null).isEmpty())
        assertTrue(AlarmCodec.decode("").isEmpty())
        assertEquals(listOf(AlarmSpec(1, 5L)), AlarmCodec.decode("x;1|5|0|0;1|2"))
    }

    @Test fun cost_calc() {
        val g = CostCfg(watt = 1000.0, tarif = 1000.0, duty = 50.0)
        assertEquals(0.5, g.kwh(3_600_000L), 1e-9)
        assertEquals(500.0, g.rupiah(3_600_000L), 1e-6)
    }
}
