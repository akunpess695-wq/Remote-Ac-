package com.example.remoteac

import org.junit.Assert.assertEquals
import org.junit.Test

class PanasonicAcTest {
    @Test fun bytes_cool_25_on() {
        val s = PanasonicAc.state(true, PanasonicAc.COOL, 25, PanasonicAc.FAN_AUTO, false)
        assertEquals(27, s.size)
        assertEquals(0x33, s[13])   // cool(3)<<4 | 0x02 | power
        assertEquals(0x32, s[14])   // 25 << 1
        assertEquals(0xA1, s[16])   // fan auto (7+3)<<4 | swing off
    }

    @Test fun power_off_clears_bit() {
        val s = PanasonicAc.state(false, PanasonicAc.COOL, 25, PanasonicAc.FAN_AUTO, false)
        assertEquals(0x32, s[13])
    }

    @Test fun checksum_is_sum_plus_f4() {
        val s = PanasonicAc.state(true, PanasonicAc.DRY, 22, 2, true)
        var sum = 0xF4
        for (i in 0 until 26) sum += s[i]
        assertEquals(sum and 0xFF, s[26])
    }

    @Test fun temp_is_clamped() {
        assertEquals(16 shl 1, PanasonicAc.state(true, 3, 5, 7, false)[14])
        assertEquals(30 shl 1, PanasonicAc.state(true, 3, 99, 7, false)[14])
    }

    @Test fun pattern_length_and_header() {
        val p = PanasonicAc.pattern(PanasonicAc.state(true, 3, 25, 7, false))
        assertEquals(440, p.size)   // frame1: 2+128+2, frame2: 2+304+2
        assertEquals(3456, p[0]); assertEquals(1728, p[1])
        assertEquals(10000, p[131])
    }

    @Test fun fan_mode_always_sends_27() {
        val s = PanasonicAc.state(true, PanasonicAc.FAN, 16, PanasonicAc.FAN_AUTO, true)
        assertEquals(27 shl 1, s[14])
    }
}
