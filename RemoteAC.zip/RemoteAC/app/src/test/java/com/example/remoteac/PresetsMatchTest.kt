package com.example.remoteac

import org.junit.Assert.assertEquals
import org.junit.Test

class PresetsMatchTest {
    private val now = 1_000_000L
    private val base = AcState(on = true)

    @Test fun each_preset_matches_itself() {
        assertEquals(0, Presets.match(Presets.hemat(base), now))
        assertEquals(1, Presets.match(Presets.powerful(base), now))
        assertEquals(2, Presets.match(Presets.tidur(base).copy(timerEnd = now + 1000), now))
        assertEquals(3, Presets.match(Presets.kering(base), now))
        assertEquals(4, Presets.match(Presets.angin(base), now))
        assertEquals(5, Presets.match(Presets.cepat(base), now))
    }

    @Test fun off_or_manual_change_clears() {
        assertEquals(-1, Presets.match(Presets.hemat(base).copy(on = false), now))
        assertEquals(-1, Presets.match(Presets.hemat(base).copy(temp = 24), now))
        assertEquals(-1, Presets.match(Presets.hemat(base).copy(fan = 3), now))
    }

    @Test fun tidur_follows_temp_rise_but_needs_timer() {
        val t = Presets.tidur(base).copy(timerEnd = now + 1000)
        assertEquals(2, Presets.match(t.copy(temp = 27), now))
        assertEquals(-1, Presets.match(t.copy(timerEnd = 0L), now))
    }

    @Test fun cepat_becomes_hemat_after_switch() {
        assertEquals(0, Presets.match(Presets.hemat(Presets.cepat(base)), now))
    }
}
