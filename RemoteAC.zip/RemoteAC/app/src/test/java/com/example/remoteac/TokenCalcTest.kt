package com.example.remoteac

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TokenCalcTest {
    private val day = 86_400_000L

    @Test fun remaining_subtracts_other_and_ac() {
        // saldo 50, 2 hari berlalu, rumah lain 5/hari, AC sejak itu 4 kWh -> 50 - 10 - 4 = 36
        val e = TokenCalc.estimate(50.0, 2 * day, 4.0, 5.0, 2.0, 3)
        assertEquals(36.0, e.remainingKwh, 1e-9)
        assertEquals(7.0, e.perDayKwh, 1e-9)
        assertEquals(36.0 / 7.0, e.daysLeft!!, 1e-9)
        assertFalse(e.warn)
    }

    @Test fun warn_when_days_left_low() {
        val e = TokenCalc.estimate(10.0, 0L, 0.0, 4.0, 1.0, 3)   // 2 hari lagi
        assertTrue(e.warn)
    }

    @Test fun never_negative_and_no_rate() {
        assertEquals(0.0, TokenCalc.estimate(5.0, 3 * day, 10.0, 1.0, 1.0, 3).remainingKwh, 1e-9)
        val e = TokenCalc.estimate(20.0, 0L, 0.0, 0.0, 0.0, 3)
        assertNull(e.daysLeft)
        assertFalse(e.warn)
    }

    @Test fun days_text() {
        assertEquals("belum bisa diperkirakan", TokenCalc.daysText(null))
        assertEquals("kurang dari 1 hari lagi", TokenCalc.daysText(0.5))
        assertEquals("±12 hari lagi", TokenCalc.daysText(12.9))
    }
}

class TokenNotifierTest {
    @Test fun should_notify_once_per_day() {
        assertTrue(TokenNotifier.shouldNotify(true, null, "20261118"))
        assertTrue(TokenNotifier.shouldNotify(true, "20261117", "20261118"))
        assertFalse(TokenNotifier.shouldNotify(true, "20261118", "20261118"))
        assertFalse(TokenNotifier.shouldNotify(false, null, "20261118"))
    }

    @Test fun next_run_is_today_or_tomorrow_at_nine() {
        fun at(h: Int, m: Int) = java.util.Calendar.getInstance().apply {
            set(2026, java.util.Calendar.NOVEMBER, 18, h, m, 0); set(java.util.Calendar.MILLISECOND, 0)
        }.timeInMillis
        assertEquals(at(9, 0), TokenNotifier.nextRun(at(7, 30)))
        val tomorrow = java.util.Calendar.getInstance().apply { timeInMillis = at(9, 0); add(java.util.Calendar.DAY_OF_YEAR, 1) }.timeInMillis
        assertEquals(tomorrow, TokenNotifier.nextRun(at(9, 0)))
        assertEquals(tomorrow, TokenNotifier.nextRun(at(15, 0)))
    }
}
