package com.example.remoteac

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DataBackupTest {
    private val sample = mapOf<String, Any>(
        "total" to 7_200_000L, "d_20261118" to 3_600_000L, "temp" to 26, "swing" to true,
        "watt" to 760.0f, "tk_balance" to 42.5f, "tk_at" to 1_700_000_000_000L,
        "on" to true, "onSince" to 5L, "timerEnd" to 9L, "tk_notified" to "20261118"
    )

    @Test fun roundtrip_keeps_data_and_skips_transient() {
        val items = DataBackup.decode(DataBackup.encode(sample))!!
        val keys = items.map { it.key }.toSet()
        assertEquals(setOf("total", "d_20261118", "temp", "swing", "watt", "tk_balance", "tk_at"), keys)
        assertEquals("42.5", items.first { it.key == "tk_balance" }.value)
        assertEquals('l', items.first { it.key == "total" }.type)
    }

    @Test fun tolerates_text_before_header() {
        val t = "Cadangan saya:\n" + DataBackup.encode(sample)
        assertTrue(DataBackup.decode(t)!!.isNotEmpty())
    }

    @Test fun rejects_garbage() {
        assertNull(DataBackup.decode(null))
        assertNull(DataBackup.decode("halo"))
        assertNull(DataBackup.decode("${DataBackup.HEADER}\ntotal|l|abc"))
        assertNull(DataBackup.decode("${DataBackup.HEADER}\nonSince|l|5"))
        assertNull(DataBackup.decode("${DataBackup.HEADER}\ntemp|i"))
    }
}

class FloatFixTest {
    @Test fun f2d_has_no_binary_noise() {
        assertEquals(1444.7, f2d(1444.7f), 0.0)
        assertEquals(0.1, f2d(0.1f), 0.0)
        assertEquals(760.0, f2d(760f), 0.0)
    }
}
