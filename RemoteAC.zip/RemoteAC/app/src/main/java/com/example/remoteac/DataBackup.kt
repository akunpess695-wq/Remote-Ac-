package com.example.remoteac

import android.content.Context

/**
 * Cadangan data sebagai teks (salin/tempel), supaya riwayat pemakaian dan saldo token
 * bisa dibawa saat app harus di-uninstall. Status sesaat (on, onSince, timerEnd) sengaja tidak ikut.
 */
object DataBackup {
    const val HEADER = "REMOTEAC-BACKUP-1"
    private val KEYS = Regex(
        "d_\\d{8}|total|temp|mode|fan|swing|freq|watt|tarif|duty|tk_balance|tk_at|tk_base|tk_other|tk_warn"
    )

    data class Item(val key: String, val type: Char, val value: String)

    fun encode(all: Map<String, *>): String {
        val sb = StringBuilder(HEADER)
        for (e in all.entries.sortedBy { it.key }) {
            if (!KEYS.matches(e.key)) continue
            val v = e.value
            val t = when (v) {
                is Boolean -> 'b'; is Int -> 'i'; is Long -> 'l'; is Float -> 'f'; else -> '?'
            }
            if (t == '?') continue
            sb.append('\n').append(e.key).append('|').append(t).append('|').append(v)
        }
        return sb.toString()
    }

    /** Null bila bukan data cadangan yang valid. Teks sebelum baris header diabaikan. */
    fun decode(text: String?): List<Item>? {
        val lines = text?.lines()?.map { it.trim() } ?: return null
        val start = lines.indexOf(HEADER)
        if (start < 0) return null
        val out = ArrayList<Item>()
        for (l in lines.drop(start + 1)) {
            if (l.isEmpty()) continue
            val f = l.split("|")
            if (f.size != 3 || f[1].length != 1 || !KEYS.matches(f[0])) return null
            val ok = when (f[1][0]) {
                'b' -> f[2] == "true" || f[2] == "false"
                'i' -> f[2].toIntOrNull() != null
                'l' -> f[2].toLongOrNull() != null
                'f' -> f[2].toFloatOrNull() != null
                else -> false
            }
            if (!ok) return null
            out += Item(f[0], f[1][0], f[2])
        }
        return out
    }

    /** Ganti semua data yang dicadangkan dengan isi [items]. */
    fun apply(c: Context, items: List<Item>) {
        val sp = AcStore.rawPrefs(c)
        val ed = sp.edit()
        sp.all.keys.filter { KEYS.matches(it) }.forEach { ed.remove(it) }
        for (i in items) when (i.type) {
            'b' -> ed.putBoolean(i.key, i.value.toBoolean())
            'i' -> ed.putInt(i.key, i.value.toInt())
            'l' -> ed.putLong(i.key, i.value.toLong())
            'f' -> ed.putFloat(i.key, i.value.toFloat())
        }
        ed.apply()
    }
}
