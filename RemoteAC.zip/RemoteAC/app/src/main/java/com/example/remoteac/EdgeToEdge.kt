package com.example.remoteac

import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.view.View
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

/** Layar penuh: status bar & navigation bar transparan, konten tidak tertutup. */
object EdgeToEdge {
    fun apply(activity: Activity, root: View) {
        val window = activity.window
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false

        val controller = WindowCompat.getInsetsController(window, root)
        controller.isAppearanceLightStatusBars = false      // ikon putih di atas biru
        controller.isAppearanceLightNavigationBars = true   // ikon gelap di bawah terang

        val l = root.paddingLeft
        val t = root.paddingTop
        val r = root.paddingRight
        val b = root.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(l + bars.left, t + bars.top, r + bars.right, b + bars.bottom)
            WindowInsetsCompat.CONSUMED
        }
    }
}
