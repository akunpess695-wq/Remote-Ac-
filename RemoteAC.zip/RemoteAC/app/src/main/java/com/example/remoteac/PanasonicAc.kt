package com.example.remoteac

/** Encoder sinyal IR AC Panasonic (216 bit = 27 byte, dua frame: 8 + 19 byte). */
object PanasonicAc {
    const val FREQ_DEFAULT = 36700
    const val FREQ_ALT = 38000

    const val AUTO = 0
    const val DRY = 2
    const val COOL = 3
    const val FAN = 6

    /** Kipas: level 0..4 (tampil 1..5), FAN_AUTO = otomatis. */
    const val FAN_AUTO = 7

    private val base = intArrayOf(
        0x02, 0x20, 0xE0, 0x04, 0x00, 0x00, 0x00, 0x06,
        0x02, 0x20, 0xE0, 0x04, 0x00, 0x02, 0x2E, 0x80,
        0xAF, 0x00, 0x00, 0x06, 0x60, 0x00, 0x00, 0x81,
        0x00, 0x00, 0x00
    )

    fun state(on: Boolean, mode: Int, temp: Int, fan: Int, swing: Boolean): IntArray {
        val s = base.copyOf()
        s[13] = (mode shl 4) or 0x02 or (if (on) 1 else 0)
        s[14] = temp.coerceIn(16, 30) shl 1
        s[16] = ((fan + 3) shl 4) or (if (swing) 0x0F else 0x01)
        s[26] = checksum(s)
        return s
    }

    fun checksum(s: IntArray): Int {
        var sum = 0xF4
        for (i in 0 until 26) sum += s[i]
        return sum and 0xFF
    }

    /** Pola mark/space (mikrodetik) untuk ConsumerIrManager.transmit. */
    fun pattern(s: IntArray): IntArray {
        val p = ArrayList<Int>(440)
        fun frame(from: Int, to: Int) {
            p += 3456; p += 1728
            for (i in from until to) for (b in 0..7) {
                p += 432
                p += if ((s[i] shr b) and 1 == 1) 1296 else 432
            }
            p += 432; p += 10000
        }
        frame(0, 8)
        frame(8, 27)
        return p.toIntArray()
    }
}
