package com.example.remoteac

import android.content.Context
import android.hardware.ConsumerIrManager

object IrSender {
    enum class Result { OK, NO_IR, ERROR }

    fun send(c: Context, s: AcState): Result {
        val ir = c.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
        if (ir == null || !ir.hasIrEmitter()) return Result.NO_IR
        return try {
            val st = PanasonicAc.state(s.on, s.mode, s.temp, s.fan, s.swing)
            ir.transmit(s.freq, PanasonicAc.pattern(st))
            Result.OK
        } catch (e: Exception) {
            Result.ERROR
        }
    }
}
