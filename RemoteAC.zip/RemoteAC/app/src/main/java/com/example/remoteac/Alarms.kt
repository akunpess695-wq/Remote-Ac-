package com.example.remoteac

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

/** Satu alarm terjadwal. code = id unik (1 timer, 11..14 Tidur, 15 Cepat lalu Hemat). */
data class AlarmSpec(val code: Int, val at: Long, val delta: Int = 0, val hemat: Boolean = false)

/** Serialisasi daftar alarm ke string supaya bisa dipasang ulang setelah HP restart. */
object AlarmCodec {
    fun encode(list: List<AlarmSpec>): String =
        list.joinToString(";") { "${it.code}|${it.at}|${it.delta}|${if (it.hemat) 1 else 0}" }

    fun decode(s: String?): List<AlarmSpec> {
        if (s.isNullOrBlank()) return emptyList()
        return s.split(";").mapNotNull { part ->
            val f = part.split("|")
            if (f.size != 4) return@mapNotNull null
            val code = f[0].toIntOrNull() ?: return@mapNotNull null
            val at = f[1].toLongOrNull() ?: return@mapNotNull null
            val delta = f[2].toIntOrNull() ?: return@mapNotNull null
            AlarmSpec(code, at, delta, f[3] == "1")
        }
    }
}

/** Semua alarm AC lewat sini, supaya pembatalan selalu bersih dan bisa dipulihkan setelah boot. */
object Alarms {
    const val CODE_TIMER = 1
    private val ALL_CODES = (1..15)

    private fun am(c: Context) = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    private fun prefs(c: Context) = c.getSharedPreferences("alarms", Context.MODE_PRIVATE)

    private fun pi(c: Context, a: AlarmSpec) = PendingIntent.getBroadcast(
        c, a.code,
        Intent(c, TimerReceiver::class.java)
            .putExtra("code", a.code).putExtra("delta", a.delta).putExtra("hemat", a.hemat),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun load(c: Context) = AlarmCodec.decode(prefs(c).getString("list", null))
    private fun store(c: Context, l: List<AlarmSpec>) =
        prefs(c).edit().putString("list", AlarmCodec.encode(l)).apply()

    /** Pakai alarm tepat bila diizinkan (Android 12+ butuh izin), kalau tidak pakai alarm hemat baterai. */
    private fun set(c: Context, a: AlarmSpec) {
        val m = am(c)
        val p = pi(c, a)
        val exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || m.canScheduleExactAlarms()
        try {
            if (exact) m.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, a.at, p)
            else m.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, a.at, p)
        } catch (e: SecurityException) {
            m.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, a.at, p)
        }
    }

    /** Batalkan SEMUA alarm AC (timer manual, Tidur, Cepat lalu Hemat). */
    fun cancelAll(c: Context) {
        val m = am(c)
        for (code in ALL_CODES) m.cancel(pi(c, AlarmSpec(code, 0)))
        store(c, emptyList())
    }

    /** Ganti seluruh jadwal dengan [list]; alarm lama dibatalkan dulu. */
    fun replaceAll(c: Context, list: List<AlarmSpec>) {
        cancelAll(c)
        list.forEach { set(c, it) }
        store(c, list)
    }

    /** Dipanggil receiver saat alarm [code] sudah berbunyi. */
    fun onFired(c: Context, code: Int) = store(c, load(c).filter { it.code != code })

    /** Setelah restart: pasang ulang alarm yang belum lewat; timerEnd yang sudah lewat dibersihkan. */
    fun restore(c: Context) {
        val now = System.currentTimeMillis()
        val future = load(c).filter { it.at > now }
        future.forEach { set(c, it) }
        store(c, future)
        val s = AcStore.load(c)
        if (s.timerEnd != 0L && s.timerEnd <= now) {
            AcStore.save(c, s.copy(timerEnd = 0L))
            AcWidget.refresh(c)
        }
    }
}
