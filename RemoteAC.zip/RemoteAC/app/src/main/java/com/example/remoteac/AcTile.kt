package com.example.remoteac

import android.content.ComponentName
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Tombol Quick Settings: ketuk untuk nyalakan/matikan AC dengan setelan terakhir. */
class AcTile : TileService() {

    override fun onStartListening() = render()

    override fun onClick() {
        val s = AcStore.load(this)
        val n = s.copy(on = !s.on)
        AcStore.save(this, n)
        IrSender.send(this, n)
        AcWidget.refresh(this)
        render()
    }

    private fun render() {
        val t = qsTile ?: return
        val s = AcStore.load(this)
        t.state = if (s.on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "Remote AC"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            t.subtitle = if (s.on) "${s.temp}° • Nyala" else "Mati"
        }
        t.updateTile()
    }

    companion object {
        /** Minta sistem memperbarui tile bila sedang terlihat. */
        fun refresh(c: android.content.Context) {
            try {
                TileService.requestListeningState(c, ComponentName(c, AcTile::class.java))
            } catch (e: Exception) { /* tile belum ditambahkan pengguna */ }
        }
    }
}
