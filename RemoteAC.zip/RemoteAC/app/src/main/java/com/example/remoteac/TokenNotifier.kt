package com.example.remoteac

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Notifikasi harian bila perkiraan token hampir habis. Alarm terpisah dari Alarms.kt agar tidak ikut terhapus. */
object TokenNotifier {
    const val CHANNEL = "token"
    const val CHECK_HOUR = 9
    private const val REQ = 100
    private const val NOTIF_ID = 100

    /** Waktu cek berikutnya: jam [hour] terdekat setelah [now]. */
    fun nextRun(now: Long, hour: Int = CHECK_HOUR): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    /** Notifikasi hanya bila perlu peringatan dan belum dikirim hari ini. */
    fun shouldNotify(warn: Boolean, lastDay: String?, today: String) = warn && lastDay != today

    private fun pi(c: Context) = PendingIntent.getBroadcast(
        c, REQ, Intent(c, TokenReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    /** Pasang cek harian berikutnya; dibatalkan bila token belum diatur. */
    fun schedule(c: Context) {
        val m = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (!AcStore.tokenCfg(c).active) { m.cancel(pi(c)); return }
        m.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextRun(System.currentTimeMillis()), pi(c))
    }

    fun check(c: Context) {
        val est = AcStore.tokenEstimate(c) ?: return
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        if (!shouldNotify(est.warn, AcStore.tokenNotifiedDay(c), today)) return
        val nm = NotificationManagerCompat.from(c)
        if (!nm.areNotificationsEnabled()) return
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(
            NotificationChannel(CHANNEL, "Peringatan token listrik", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val open = PendingIntent.getActivity(
            c, REQ, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val text = "Token ${TokenCalc.daysText(est.daysLeft)} (sisa ±${"%.1f".format(est.remainingKwh)} kWh). Siapkan beli token."
        val n = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_bolt)
            .setContentTitle("Token listrik hampir habis")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try {
            nm.notify(NOTIF_ID, n)
            AcStore.setTokenNotifiedDay(c, today)
        } catch (e: SecurityException) { /* izin dicabut */ }
    }
}

class TokenReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        TokenNotifier.check(c)
        TokenNotifier.schedule(c)
    }
}
