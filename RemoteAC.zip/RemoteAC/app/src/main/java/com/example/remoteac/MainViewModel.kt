package com.example.remoteac

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val _state = MutableLiveData(AcStore.load(ctx))
    private val _result = MutableLiveData<IrSender.Result>()
    val state: LiveData<AcState> = _state
    val result: LiveData<IrSender.Result> = _result

    private fun cur() = AcStore.load(ctx)

    private fun apply(s: AcState, send: Boolean = true) {
        AcStore.save(ctx, s)
        _state.value = s
        AcWidget.refresh(ctx)
        if (send) _result.value = IrSender.send(ctx, s)
    }

    fun refresh() { _state.value = cur() }
    fun togglePower() = cur().let { apply(it.copy(on = !it.on)) }
    fun tempDelta(d: Int) = cur().let { apply(it.copy(temp = (it.temp + d).coerceIn(16, 30), on = true)) }
    fun setTemp(v: Int) = cur().let { apply(it.copy(temp = v.coerceIn(16, 30), on = true)) }
    fun setMode(m: Int) = cur().let { apply(it.copy(mode = m)) }
    fun setFan(f: Int) = cur().let { apply(it.copy(fan = f)) }
    fun setSwing(v: Boolean) = cur().let { apply(it.copy(swing = v)) }
    fun resend() = apply(cur())

    /** Rahasia: tekan lama angka suhu untuk ganti frekuensi carrier. */
    fun toggleFreq() = cur().let {
        val f = if (it.freq == PanasonicAc.FREQ_DEFAULT) PanasonicAc.FREQ_ALT else PanasonicAc.FREQ_DEFAULT
        apply(it.copy(freq = f))
    }

    /** minutes <= 0 membatalkan timer. Selalu membatalkan alarm Tidur/Cepat yang masih tersisa. */
    fun setTimer(minutes: Int) {
        var end = 0L
        if (minutes > 0) {
            end = System.currentTimeMillis() + minutes * 60_000L
            Alarms.replaceAll(ctx, listOf(AlarmSpec(Alarms.CODE_TIMER, end)))
        } else {
            Alarms.cancelAll(ctx)
        }
        apply(cur().copy(timerEnd = end), send = false)
    }

    /** 0 Hemat, 1 Powerful, 2 Tidur, 3 Kering, 4 Angin, 5 Cepat 15 menit lalu Hemat. */
    fun preset(n: Int) {
        val now = System.currentTimeMillis()
        val base = cur().copy(on = true, timerEnd = 0L)
        val s = when (n) {
            0 -> Presets.hemat(base)
            1 -> Presets.powerful(base)
            2 -> Presets.tidur(base)
            3 -> Presets.kering(base)
            5 -> Presets.cepat(base)
            else -> Presets.angin(base)
        }
        var end = 0L
        val alarms = ArrayList<AlarmSpec>()
        if (n == 2) {
            for (k in 1..2) alarms += AlarmSpec(10 + k, now + k * 3_600_000L, delta = 1)
            end = now + 7 * 3_600_000L
            alarms += AlarmSpec(14, end)
        }
        if (n == 5) alarms += AlarmSpec(15, now + 15 * 60_000L, hemat = true)
        Alarms.replaceAll(ctx, alarms) // membatalkan semua alarm lama, termasuk timer manual
        apply(s.copy(timerEnd = end))
    }
}
