package com.example.remoteac

import android.app.AlarmManager
import android.app.Application
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val _state = MutableLiveData(AcStore.load(ctx))
    private val _result = MutableLiveData<IrSender.Result>()
    val state: LiveData<AcState> = _state
    val result: LiveData<IrSender.Result> = _result

    private fun cur() = AcStore.load(ctx)

    private fun apply(s: AcState, send: Boolean = true) {
        AcStore.save(ctx, s)
        _state.value = s
        AcWidget.refresh(ctx)
        if (send) _result.value = IrSender.send(ctx, s)
    }

    fun refresh() { _state.value = cur() }
    fun togglePower() = cur().let { apply(it.copy(on = !it.on)) }
    fun tempDelta(d: Int) = cur().let { apply(it.copy(temp = (it.temp + d).coerceIn(16, 30), on = true)) }
    fun setMode(m: Int) = cur().let { apply(it.copy(mode = m)) }
    fun setFan(f: Int) = cur().let { apply(it.copy(fan = f)) }
    fun setSwing(v: Boolean) = cur().let { apply(it.copy(swing = v)) }
    fun resend() = apply(cur())

    /** Rahasia: tekan lama angka suhu untuk ganti frekuensi carrier. */
    fun toggleFreq() = cur().let {
        val f = if (it.freq == PanasonicAc.FREQ_DEFAULT) PanasonicAc.FREQ_ALT else PanasonicAc.FREQ_DEFAULT
        apply(it.copy(freq = f))
    }

    /** minutes <= 0 membatalkan timer. */
    fun setTimer(minutes: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            ctx, 1, Intent(ctx, TimerReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
        var end = 0L
        if (minutes > 0) {
            end = System.currentTimeMillis() + minutes * 60_000L
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi)
        }
        apply(cur().copy(timerEnd = end), send = false)
    }
}
