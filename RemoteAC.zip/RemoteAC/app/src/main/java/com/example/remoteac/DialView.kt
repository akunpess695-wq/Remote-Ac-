package com.example.remoteac

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Dial suhu melingkar 16-30°C. Geser busur; sinyal dikirim saat jari diangkat. */
class DialView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    var temp = 25
        set(v) { field = v.coerceIn(16, 30); invalidate() }
    var on = false
        set(v) { field = v; invalidate() }
    var onTempCommit: ((Int) -> Unit)? = null

    private val dp = resources.displayMetrics.density
    private val stroke = 14 * dp
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = stroke; strokeCap = Paint.Cap.ROUND; color = 0xFFBBDEFB.toInt()
    }
    private val prog = Paint(track)
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; setShadowLayer(6 * dp, 0f, 2 * dp, 0x55000000)
    }
    private val tPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF0D47A1.toInt(); textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD
    }
    private val sPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF37474F.toInt(); textSize = 13 * dp }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()
    private var dragging = false
    private var dragTemp = 25

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val r = min(w, h) / 2f - stroke
        oval.set(w / 2f - r, h / 2f - r, w / 2f + r, h / 2f + r)
        val g = SweepGradient(w / 2f, h / 2f, intArrayOf(0xFF4FC3F7.toInt(), 0xFF1565C0.toInt()), floatArrayOf(0f, SWEEP / 360f))
        g.setLocalMatrix(Matrix().apply { postRotate(START, w / 2f, h / 2f) })
        prog.shader = g
    }

    override fun onDraw(canvas: Canvas) {
        val shown = if (dragging) dragTemp else temp
        val frac = (shown - 16) / 14f
        canvas.drawArc(oval, START, SWEEP, false, track)
        if (frac > 0f) canvas.drawArc(oval, START, SWEEP * frac, false, prog)

        val r = oval.width() / 2f
        val ang = Math.toRadians((START + SWEEP * frac).toDouble())
        canvas.drawCircle(oval.centerX() + r * cos(ang).toFloat(), oval.centerY() + r * sin(ang).toFloat(), stroke * 0.8f, thumb)

        tPaint.textSize = r * 0.8f
        canvas.drawText("$shown°", oval.centerX(), oval.centerY() + tPaint.textSize * 0.3f, tPaint)

        val label = if (on) "AC menyala" else "AC mati"
        dot.color = if (on) 0xFF43A047.toInt() else 0xFF9E9E9E.toInt()
        val dr = 5 * dp
        val sx = oval.centerX() - (dr * 2 + 6 * dp + sPaint.measureText(label)) / 2f
        val sy = oval.centerY() + r * 0.6f
        canvas.drawCircle(sx + dr, sy - sPaint.textSize * 0.33f, dr, dot)
        canvas.drawText(label, sx + dr * 2 + 6 * dp, sy, sPaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                dragging = true; dragTemp = temp; update(e); return true
            }
            MotionEvent.ACTION_MOVE -> { update(e); return true }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    dragging = false; invalidate()
                    if (e.actionMasked == MotionEvent.ACTION_UP && dragTemp != temp) onTempCommit?.invoke(dragTemp)
                }
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    private fun update(e: MotionEvent) {
        var a = Math.toDegrees(atan2((e.y - height / 2f).toDouble(), (e.x - width / 2f).toDouble())).toFloat()
        if (a < 0) a += 360f
        var rel = (a - START + 360f) % 360f
        if (rel > SWEEP) rel = if (rel - SWEEP < (360f - SWEEP) / 2f) SWEEP else 0f
        dragTemp = (16 + (rel / SWEEP * 14f).roundToInt()).coerceIn(16, 30)
        invalidate()
    }

    companion object {
        private const val START = 135f
        private const val SWEEP = 270f
    }
}
