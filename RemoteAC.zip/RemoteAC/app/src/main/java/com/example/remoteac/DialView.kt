package com.example.remoteac

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Dial suhu melingkar 16-30°C. Geser busur; sinyal dikirim saat jari diangkat. Selalu persegi. */
class DialView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    var temp = 25
        set(v) { field = v.coerceIn(16, 30); invalidate() }
    var on = false
        set(v) { field = v; invalidate() }
    var onTempCommit: ((Int) -> Unit)? = null
    /** Ikon mode (Cool/Dry/Fan/Auto) di atas angka suhu. */
    var icon: Drawable? = null
        set(v) { field = v; invalidate() }

    private val dp = resources.displayMetrics.density

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = 0x80FFFFFF.toInt()
    }
    private val prog = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val face = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val faceEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0xCCFFFFFF.toInt()
    }
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val thumbEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0xFFCFE2FF.toInt()
    }
    private val tPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = INK; textAlign = Paint.Align.LEFT
        typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
    }
    private val degPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = INK }
    private val cPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = INK; textAlign = Paint.Align.LEFT
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val sPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = INK; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)

    private val oval = RectF()
    private val tb = Rect()
    private var cx = 0f
    private var cy = 0f
    private var stroke = 12 * dp
    private var faceR = 0f
    private var thumbR = 0f
    private var dragging = false
    private var dragTemp = 25

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    /** Tinggi selalu sama dengan lebar. */
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val size = if (w > 0) w else (190 * dp).toInt()
        setMeasuredDimension(size, size)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val size = min(w, h).toFloat()
        cx = w / 2f; cy = h / 2f
        stroke = size * 0.075f
        val ringR = size / 2f - stroke * 1.35f
        oval.set(cx - ringR, cy - ringR, cx + ringR, cy + ringR)
        faceR = ringR - stroke * 0.95f
        thumbR = stroke * 0.95f

        track.strokeWidth = stroke
        prog.strokeWidth = stroke * 0.8f
        faceEdge.strokeWidth = 1.5f * dp
        thumbEdge.strokeWidth = 1f * dp

        val g = SweepGradient(cx, cy, intArrayOf(0xFF5AB4FF.toInt(), 0xFF1560F0.toInt()), floatArrayOf(0f, SWEEP / 360f))
        g.setLocalMatrix(Matrix().apply { postRotate(START, cx, cy) })
        prog.shader = g

        face.shader = RadialGradient(
            cx, cy - faceR * 0.35f, faceR * 1.5f,
            intArrayOf(0xFFFFFFFF.toInt(), 0xFFD8E8FF.toInt()), null, Shader.TileMode.CLAMP
        )
        face.setShadowLayer(stroke * 0.9f, 0f, stroke * 0.3f, 0x401040A0)
        thumb.setShadowLayer(stroke * 0.3f, 0f, stroke * 0.12f, 0x55000000)

        tPaint.textSize = faceR * 0.85f
        cPaint.textSize = faceR * 0.34f
        degPaint.strokeWidth = faceR * 0.05f
        sPaint.textSize = faceR * 0.19f
    }

    override fun onDraw(canvas: Canvas) {
        val shown = if (dragging) dragTemp else temp
        val frac = (shown - 16) / 14f

        // jalur & muka dial
        canvas.drawArc(oval, START, SWEEP, false, track)
        canvas.drawCircle(cx, cy, faceR, face)
        canvas.drawCircle(cx, cy, faceR, faceEdge)

        // busur progres + knob
        if (frac > 0f) canvas.drawArc(oval, START, SWEEP * frac, false, prog)
        val r = oval.width() / 2f
        val ang = Math.toRadians((START + SWEEP * frac).toDouble())
        val tx = oval.centerX() + r * cos(ang).toFloat()
        val ty = oval.centerY() + r * sin(ang).toFloat()
        canvas.drawCircle(tx, ty, thumbR, thumb)
        canvas.drawCircle(tx, ty, thumbR, thumbEdge)

        // ikon mode
        icon?.let {
            val half = (faceR * 0.19f).toInt()
            val ix = cx.toInt()
            val iy = (cy - faceR * 0.68f).toInt()
            it.setBounds(ix - half, iy - half, ix + half, iy + half)
            it.setTint(0xFF0B5BE6.toInt())
            it.draw(canvas)
        }

        // angka suhu + "°C" (derajat digambar sebagai cincin)
        val num = shown.toString()
        tPaint.getTextBounds(num, 0, num.length, tb)
        val numW = tPaint.measureText(num)
        val numH = tb.height().toFloat()
        cPaint.getTextBounds("C", 0, 1, tb)
        val cH = tb.height().toFloat()
        val cW = cPaint.measureText("C")
        val degD = cPaint.textSize * 0.5f
        val gap = tPaint.textSize * 0.04f
        val total = numW + gap + degD + gap * 0.5f + cW
        val startX = cx - total / 2f
        val baseline = cy + faceR * 0.06f + numH / 2f
        val top = baseline - numH
        canvas.drawText(num, startX, baseline, tPaint)
        val degX = startX + numW + gap
        canvas.drawCircle(degX + degD / 2f, top + degD / 2f + degPaint.strokeWidth, degD / 2f - degPaint.strokeWidth / 2f, degPaint)
        canvas.drawText("C", degX + degD + gap * 0.5f, top + cH + degPaint.strokeWidth, cPaint)

        // status
        val label = if (on) "AC menyala" else "AC mati"
        dot.color = if (on) 0xFF22C55E.toInt() else 0xFF9E9E9E.toInt()
        val dr = sPaint.textSize * 0.3f
        val gap2 = sPaint.textSize * 0.45f
        val sw = dr * 2 + gap2 + sPaint.measureText(label)
        val sx = cx - sw / 2f
        val sy = cy + faceR * 0.68f
        canvas.drawCircle(sx + dr, sy - sPaint.textSize * 0.33f, dr, dot)
        canvas.drawText(label, sx + dr * 2 + gap2, sy, sPaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                dragging = true; dragTemp = temp; update(e); return true
            }
            MotionEvent.ACTION_MOVE -> { update(e); return true }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    dragging = false; invalidate()
                    if (e.actionMasked == MotionEvent.ACTION_UP && dragTemp != temp) onTempCommit?.invoke(dragTemp)
                }
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    private fun update(e: MotionEvent) {
        var a = Math.toDegrees(atan2((e.y - height / 2f).toDouble(), (e.x - width / 2f).toDouble())).toFloat()
        if (a < 0) a += 360f
        var rel = (a - START + 360f) % 360f
        if (rel > SWEEP) rel = if (rel - SWEEP < (360f - SWEEP) / 2f) SWEEP else 0f
        dragTemp = (16 + (rel / SWEEP * 14f).roundToInt()).coerceIn(16, 30)
        invalidate()
    }

    companion object {
        private const val START = 135f
        private const val SWEEP = 270f
        private val INK = 0xFF0B2E8A.toInt()
    }
}
