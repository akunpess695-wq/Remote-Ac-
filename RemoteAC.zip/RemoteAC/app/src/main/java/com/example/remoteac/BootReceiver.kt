package com.example.remoteac

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Pasang ulang timer/preset yang hilang saat HP restart. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) {
            Alarms.restore(c)
            TokenNotifier.schedule(c)
        }
    }
}
