package com.example.remoteac

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Alarm: delta != 0 = naikkan suhu (preset Tidur); delta == 0 = matikan AC. */
class TimerReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val d = i.getIntExtra("delta", 0)
        val old = AcStore.load(c)
        val s = if (d != 0) {
            if (!old.on) return
            old.copy(temp = (old.temp + d).coerceIn(16, 30))
        } else old.copy(on = false, timerEnd = 0L)
        AcStore.save(c, s)
        IrSender.send(c, s)
        AcWidget.refresh(c)
    }
}
