package com.example.remoteac

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Alarm: hemat = pindah ke setelan hemat; delta != 0 = naikkan suhu; selain itu matikan AC. */
class TimerReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val d = i.getIntExtra("delta", 0)
        val old = AcStore.load(c)
        val s = when {
            i.getBooleanExtra("hemat", false) -> {
                if (!old.on) return
                old.copy(mode = PanasonicAc.COOL, temp = 25, fan = PanasonicAc.FAN_AUTO, swing = true)
            }
            d != 0 -> {
                if (!old.on) return
                old.copy(temp = (old.temp + d).coerceIn(16, 30))
            }
            else -> old.copy(on = false, timerEnd = 0L)
        }
        AcStore.save(c, s)
        IrSender.send(c, s)
        AcWidget.refresh(c)
    }
}
