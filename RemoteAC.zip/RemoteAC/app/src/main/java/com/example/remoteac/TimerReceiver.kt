package com.example.remoteac

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Dipanggil AlarmManager saat timer habis: matikan AC walau layar mati. */
class TimerReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val s = AcStore.load(c).copy(on = false, timerEnd = 0L)
        AcStore.save(c, s)
        IrSender.send(c, s)
        AcWidget.refresh(c)
    }
}
