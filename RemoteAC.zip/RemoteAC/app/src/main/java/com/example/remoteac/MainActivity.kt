package com.example.remoteac

import android.os.Bundle
import android.text.InputType
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.remoteac.databinding.ActivityMainBinding
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val vm: MainViewModel by viewModels()
    private var rendering = false

    private val modeIds get() = mapOf(
        b.mCool.id to PanasonicAc.COOL, b.mDry.id to PanasonicAc.DRY,
        b.mFan.id to PanasonicAc.FAN, b.mAuto.id to PanasonicAc.AUTO
    )
    private val fanIds get() = mapOf(
        b.fAuto.id to PanasonicAc.FAN_AUTO, b.f0.id to 0, b.f1.id to 1,
        b.f2.id to 2, b.f3.id to 3, b.f4.id to 4
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        fun tap(v: View, f: () -> Unit) = v.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); f()
        }
        tap(b.btnPower) { vm.togglePower() }
        tap(b.btnPlus) { vm.tempDelta(1) }
        tap(b.btnMinus) { vm.tempDelta(-1) }
        tap(b.btnResend) { vm.resend() }
        tap(b.btnTimer) { showTimerDialog() }
        tap(b.btnCost) { showCostDialog() }
        val dp = resources.displayMetrics.density
        listOf("Hemat", "Powerful", "Tidur", "Kering", "Angin", "Cepat lalu Hemat").forEachIndexed { i, n ->
            val btn = com.google.android.material.button.MaterialButton(
                this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle
            ).apply { text = n; textSize = 15f; maxLines = 2; setPadding((6 * dp).toInt(), 0, (6 * dp).toInt(), 0) }
            btn.layoutParams = android.widget.LinearLayout.LayoutParams(0, (64 * dp).toInt(), 1f)
                .apply { setMargins((3 * dp).toInt(), 0, (3 * dp).toInt(), 0) }
            tap(btn) { vm.preset(i) }
            (if (i < 3) b.presetRow1 else b.presetRow2).addView(btn)
        }
        b.swSwing.setOnCheckedChangeListener { v, on ->
            if (!rendering) { v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); vm.setSwing(on) }
        }
        b.tgMode.addOnButtonCheckedListener { _, id, checked ->
            if (checked && !rendering) modeIds[id]?.let { vm.setMode(it) }
        }
        b.tgFan.setOnCheckedStateChangeListener { _, ids ->
            if (!rendering) ids.firstOrNull()?.let { id -> fanIds[id]?.let { vm.setFan(it) } }
        }
        b.tvTemp.setOnLongClickListener {
            vm.toggleFreq()
            val f = vm.state.value?.freq ?: 0
            Toast.makeText(this, "Carrier IR: ${f / 1000.0} kHz", Toast.LENGTH_SHORT).show()
            true
        }

        vm.state.observe(this) { render(it) }
        vm.result.observe(this) {
            when (it) {
                IrSender.Result.NO_IR -> toast("HP ini tidak punya IR blaster")
                IrSender.Result.ERROR -> toast("Gagal mengirim sinyal, coba lagi")
                else -> {}
            }
        }
    }

    override fun onResume() { super.onResume(); vm.refresh() }

    private fun render(s: AcState) {
        rendering = true
        b.tvTemp.text = "${s.temp}°"
        val timer = if (s.timerEnd > System.currentTimeMillis())
            "  •  mati jam " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(s.timerEnd)) else ""
        b.tvInfo.text = (if (s.on) "AC menyala" else "AC mati") + timer
        b.btnPower.text = if (s.on) "MATIKAN" else "NYALAKAN"
        b.tgMode.check(modeIds.entries.firstOrNull { it.value == s.mode }?.key ?: b.mCool.id)
        b.tgFan.check(fanIds.entries.firstOrNull { it.value == s.fan }?.key ?: b.fAuto.id)
        b.swSwing.isChecked = s.swing
        rendering = false
        renderCost()
    }

    private fun renderCost() {
        val g = AcStore.costCfg(this)
        val nf = NumberFormat.getInstance(Locale("id", "ID"))
        fun line(label: String, days: Int): String {
            val ms = AcStore.usageMs(this, days)
            val m = ms / 60_000
            return "$label: ${m / 60} j ${m % 60} m  •  ±${"%.1f".format(g.kwh(ms))} kWh  •  ±Rp${nf.format(Math.round(g.rupiah(ms)))}"
        }
        b.tvCost.text = "Perkiraan listrik AC\n" + line("Hari ini", 1) + "\n" + line("30 hari", 30)
    }

    private fun showCostDialog() {
        val g = AcStore.costCfg(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
        fun field(label: String, v: Double): EditText {
            box.addView(TextView(this).apply { text = label; setPadding(0, 16, 0, 0) })
            return EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                setText(if (v % 1.0 == 0.0) v.toLong().toString() else v.toString())
                box.addView(this)
            }
        }
        val w = field("Daya AC (watt)", g.watt)
        val tr = field("Tarif listrik (Rp per kWh)", g.tarif)
        val dt = field("Faktor kompresor (%) - perkiraan berapa persen waktu kompresor benar-benar jalan", g.duty)
        AlertDialog.Builder(this)
            .setTitle("Atur perkiraan listrik")
            .setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                AcStore.saveCostCfg(this, CostCfg(
                    w.text.toString().toDoubleOrNull() ?: g.watt,
                    tr.text.toString().toDoubleOrNull() ?: g.tarif,
                    dt.text.toString().toDoubleOrNull() ?: g.duty
                ))
                renderCost()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showTimerDialog() {
        val labels = arrayOf("30 menit", "1 jam", "2 jam", "4 jam", "8 jam", "Batalkan timer")
        val mins = intArrayOf(30, 60, 120, 240, 480, 0)
        AlertDialog.Builder(this)
            .setTitle("Matikan AC otomatis")
            .setItems(labels) { _, i ->
                vm.setTimer(mins[i])
                toast(if (mins[i] > 0) "Timer: ${labels[i]}" else "Timer dibatalkan")
            }
            .show()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
