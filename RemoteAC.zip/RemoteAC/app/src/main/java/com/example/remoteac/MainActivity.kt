package com.example.remoteac

import android.content.Intent
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.content.ContextCompat
import com.example.remoteac.databinding.ActivityMainBinding
import com.google.android.material.button.MaterialButton
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val vm: MainViewModel by viewModels()
    private var rendering = false

    private val modeIds get() = mapOf(
        b.mCool.id to PanasonicAc.COOL, b.mDry.id to PanasonicAc.DRY,
        b.mFan.id to PanasonicAc.FAN, b.mAuto.id to PanasonicAc.AUTO
    )
    private val fanBtns get() = listOf(
        b.fAuto to PanasonicAc.FAN_AUTO, b.f0 to 0, b.f1 to 1,
        b.f2 to 2, b.f3 to 3, b.f4 to 4
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        EdgeToEdge.apply(this, b.root)

        fun tap(v: View, f: () -> Unit) = v.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); f()
        }
        tap(b.btnPower) { vm.togglePower() }
        tap(b.btnPlus) { vm.tempDelta(1) }
        tap(b.btnMinus) { vm.tempDelta(-1) }
        tap(b.btnResend) { vm.resend() }
        tap(b.btnTimer) { showTimerDialog() }
        tap(b.btnSettings) { startActivity(Intent(this, SettingsActivity::class.java)) }
        b.dial.onTempCommit = { vm.setTemp(it) }

        val dp = resources.displayMetrics.density
        listOf(
            "Hemat" to R.drawable.ic_leaf, "Powerful" to R.drawable.ic_bolt,
            "Tidur" to R.drawable.ic_moon, "Kering" to R.drawable.ic_drop,
            "Angin" to R.drawable.ic_wind, "Cepat lalu Hemat" to R.drawable.ic_star
        ).forEachIndexed { i, (n, ic) ->
            val col = i % 3
            val btn = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = n; textSize = 13f; maxLines = 2
                textAlignment = View.TEXT_ALIGNMENT_CENTER
                setIconResource(ic)
                iconGravity = MaterialButton.ICON_GRAVITY_TEXT_TOP
                iconSize = (22 * dp).toInt()
                iconPadding = (2 * dp).toInt()
            }
            btn.layoutParams = LinearLayout.LayoutParams(0, (62 * dp).toInt(), 1f).apply {
                marginStart = if (col == 0) 0 else (4 * dp).toInt()
                marginEnd = if (col == 2) 0 else (4 * dp).toInt()
            }
            tap(btn) { vm.preset(i) }
            (if (i < 3) b.presetRow1 else b.presetRow2).addView(btn)
        }

        b.presetHeader.setOnClickListener {
            val open = b.presetBody.visibility != View.VISIBLE
            b.presetBody.visibility = if (open) View.VISIBLE else View.GONE
            b.ivPresetChevron.animate().rotation(if (open) 0f else -90f).setDuration(150).start()
        }

        b.swSwing.setOnCheckedChangeListener { v, on ->
            if (!rendering) { v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); vm.setSwing(on) }
        }
        b.tgMode.addOnButtonCheckedListener { _, id, checked ->
            if (checked && !rendering) modeIds[id]?.let { vm.setMode(it) }
        }
        fanBtns.forEach { (btn, speed) ->
            tap(btn) { if (!rendering && !btn.isSelected) vm.setFan(speed) }
        }

        vm.state.observe(this) { render(it) }
        vm.result.observe(this) {
            when (it) {
                IrSender.Result.NO_IR -> toast("HP ini tidak punya IR blaster")
                IrSender.Result.ERROR -> toast("Gagal mengirim sinyal, coba lagi")
                else -> {}
            }
        }
    }

    override fun onResume() { super.onResume(); vm.refresh(); TokenNotifier.schedule(this) }

    private fun render(s: AcState) {
        rendering = true
        b.dial.temp = s.temp
        b.dial.on = s.on
        val lines = ArrayList<String>()
        if (s.timerEnd > System.currentTimeMillis()) {
            lines += "Mati otomatis jam " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(s.timerEnd))
        }
        val tk = AcStore.tokenEstimate(this)
        if (tk != null) {
            lines += (if (tk.warn) "⚠ " else "") + "Token ${TokenCalc.daysText(tk.daysLeft)} (sisa ±${"%.0f".format(tk.remainingKwh)} kWh)"
        }
        b.tvInfo.visibility = if (lines.isEmpty()) View.GONE else View.VISIBLE
        b.tvInfo.text = lines.joinToString("\n")
        b.tvInfo.setTextColor(
            if (tk?.warn == true) 0xFFC62828.toInt() else ContextCompat.getColor(this, R.color.ink)
        )
        b.btnPower.contentDescription = if (s.on) "Matikan AC" else "Nyalakan AC"
        b.tgMode.check(modeIds.entries.firstOrNull { it.value == s.mode }?.key ?: b.mCool.id)
        val fanSel = if (fanBtns.any { it.second == s.fan }) s.fan else PanasonicAc.FAN_AUTO
        fanBtns.forEach { (btn, speed) -> btn.isSelected = speed == fanSel }
        b.fAuto.icon = if (fanSel == PanasonicAc.FAN_AUTO)
            AppCompatResources.getDrawable(this, R.drawable.ic_check) else null
        b.swSwing.isChecked = s.swing
        val (label, icon) = when (s.mode) {
            PanasonicAc.DRY -> "Dry" to R.drawable.ic_drop
            PanasonicAc.FAN -> "Fan" to R.drawable.ic_fan
            PanasonicAc.AUTO -> "Auto" to R.drawable.ic_refresh
            else -> "Cool" to R.drawable.ic_snow
        }
        b.tvModeLabel.text = label
        b.ivMode.setImageResource(icon)
        b.dial.icon = AppCompatResources.getDrawable(this, icon)?.mutate()
        b.tvFanLabel.text = "Fan " + if (s.fan == PanasonicAc.FAN_AUTO) "Auto" else "${s.fan + 1}"
        rendering = false
    }

    private fun showTimerDialog() {
        val labels = arrayOf("30 menit", "1 jam", "2 jam", "4 jam", "8 jam", "Batalkan timer")
        val mins = intArrayOf(30, 60, 120, 240, 480, 0)
        AlertDialog.Builder(this)
            .setTitle("Matikan AC otomatis")
            .setItems(labels) { _, i ->
                vm.setTimer(mins[i])
                toast(if (mins[i] > 0) "Timer: ${labels[i]}" else "Timer dibatalkan")
            }
            .show()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
