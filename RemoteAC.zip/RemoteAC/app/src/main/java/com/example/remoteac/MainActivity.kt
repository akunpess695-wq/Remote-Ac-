package com.example.remoteac

import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.remoteac.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val vm: MainViewModel by viewModels()
    private var rendering = false

    private val modeIds get() = mapOf(
        b.mCool.id to PanasonicAc.COOL, b.mDry.id to PanasonicAc.DRY,
        b.mFan.id to PanasonicAc.FAN, b.mAuto.id to PanasonicAc.AUTO
    )
    private val fanIds get() = mapOf(
        b.fAuto.id to PanasonicAc.FAN_AUTO, b.f0.id to 0, b.f1.id to 1,
        b.f2.id to 2, b.f3.id to 3, b.f4.id to 4
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        fun tap(v: View, f: () -> Unit) = v.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); f()
        }
        tap(b.btnPower) { vm.togglePower() }
        tap(b.btnPlus) { vm.tempDelta(1) }
        tap(b.btnMinus) { vm.tempDelta(-1) }
        tap(b.btnResend) { vm.resend() }
        tap(b.btnTimer) { showTimerDialog() }
        val gap = (8 * resources.displayMetrics.density).toInt()
        listOf("Hemat", "Powerful", "Tidur", "Kering", "Angin").forEachIndexed { i, n ->
            val btn = com.google.android.material.button.MaterialButton(
                this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle
            ).apply { text = n; textSize = 16f }
            btn.layoutParams = android.widget.LinearLayout.LayoutParams(-2, (52 * resources.displayMetrics.density).toInt())
                .apply { marginEnd = gap }
            tap(btn) { vm.preset(i) }
            b.presetRow.addView(btn)
        }
        b.swSwing.setOnCheckedChangeListener { v, on ->
            if (!rendering) { v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); vm.setSwing(on) }
        }
        b.tgMode.addOnButtonCheckedListener { _, id, checked ->
            if (checked && !rendering) modeIds[id]?.let { vm.setMode(it) }
        }
        b.tgFan.addOnButtonCheckedListener { _, id, checked ->
            if (checked && !rendering) fanIds[id]?.let { vm.setFan(it) }
        }
        b.tvTemp.setOnLongClickListener {
            vm.toggleFreq()
            val f = vm.state.value?.freq ?: 0
            Toast.makeText(this, "Carrier IR: ${f / 1000.0} kHz", Toast.LENGTH_SHORT).show()
            true
        }

        vm.state.observe(this) { render(it) }
        vm.result.observe(this) {
            when (it) {
                IrSender.Result.NO_IR -> toast("HP ini tidak punya IR blaster")
                IrSender.Result.ERROR -> toast("Gagal mengirim sinyal, coba lagi")
                else -> {}
            }
        }
    }

    override fun onResume() { super.onResume(); vm.refresh() }

    private fun render(s: AcState) {
        rendering = true
        b.tvTemp.text = "${s.temp}°"
        val timer = if (s.timerEnd > System.currentTimeMillis())
            "  •  mati jam " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(s.timerEnd)) else ""
        b.tvInfo.text = (if (s.on) "AC menyala" else "AC mati") + timer
        b.btnPower.text = if (s.on) "MATIKAN" else "NYALAKAN"
        b.tgMode.check(modeIds.entries.firstOrNull { it.value == s.mode }?.key ?: b.mCool.id)
        b.tgFan.check(fanIds.entries.firstOrNull { it.value == s.fan }?.key ?: b.fAuto.id)
        b.swSwing.isChecked = s.swing
        rendering = false
    }

    private fun showTimerDialog() {
        val labels = arrayOf("30 menit", "1 jam", "2 jam", "4 jam", "8 jam", "Batalkan timer")
        val mins = intArrayOf(30, 60, 120, 240, 480, 0)
        AlertDialog.Builder(this)
            .setTitle("Matikan AC otomatis")
            .setItems(labels) { _, i ->
                vm.setTimer(mins[i])
                toast(if (mins[i] > 0) "Timer: ${labels[i]}" else "Timer dibatalkan")
            }
            .show()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
