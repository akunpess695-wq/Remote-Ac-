package com.example.remoteac

/**
 * Setelan preset. Prinsip hemat listrik pada AC inverter:
 * - Suhu setelan tinggi (26°) + kipas sedang: angin membuat badan terasa lebih sejuk,
 *   sedangkan tiap 1° lebih tinggi menghemat kira-kira 3-5% listrik.
 * - Hindari suhu 16-18° lama-lama: kompresor dipaksa maksimal, ruangan tidak lebih cepat nyaman.
 * - Tarik suhu turun sebentar saja (15 menit), lalu pindah ke setelan hemat.
 */
object Presets {
    const val HEMAT_TEMP = 26
    const val HEMAT_FAN = 2 // tampil "Fan 3" (sedang)

    fun hemat(s: AcState) = s.copy(
        on = true, mode = PanasonicAc.COOL, temp = HEMAT_TEMP, fan = HEMAT_FAN, swing = true
    )

    /** Turun cepat: dingin dulu, lalu pindah otomatis ke [hemat]. */
    fun cepat(s: AcState) = s.copy(
        on = true, mode = PanasonicAc.COOL, temp = 20, fan = 4, swing = true
    )

    fun powerful(s: AcState) = s.copy(
        on = true, mode = PanasonicAc.COOL, temp = 16, fan = 4, swing = true
    )

    /** Tidur: mulai 25°, naik 1° tiap jam sampai 27° (jam ke-2), kipas pelan, mati setelah 7 jam. */
    fun tidur(s: AcState) = s.copy(
        on = true, mode = PanasonicAc.COOL, temp = 25, fan = 0, swing = false
    )

    fun kering(s: AcState) = s.copy(
        on = true, mode = PanasonicAc.DRY, temp = 26, fan = PanasonicAc.FAN_AUTO, swing = false
    )

    fun angin(s: AcState) = s.copy(
        on = true, mode = PanasonicAc.FAN, fan = PanasonicAc.FAN_AUTO, swing = true
    )
}
