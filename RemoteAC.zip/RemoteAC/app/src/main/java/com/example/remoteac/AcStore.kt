package com.example.remoteac

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class AcState(
    val on: Boolean = false,
    val temp: Int = 25,
    val mode: Int = PanasonicAc.COOL,
    val fan: Int = PanasonicAc.FAN_AUTO,
    val swing: Boolean = false,
    val freq: Int = PanasonicAc.FREQ_DEFAULT,
    val timerEnd: Long = 0L
)

/** Pengaturan perkiraan listrik: daya AC (watt), tarif (Rp/kWh), faktor kompresor (%). */
data class CostCfg(val watt: Double = 760.0, val tarif: Double = 1444.7, val duty: Double = 70.0) {
    fun kwh(ms: Long) = ms / 3_600_000.0 * watt / 1000.0 * duty / 100.0
    fun rupiah(ms: Long) = kwh(ms) * tarif
}

/** Simpan/muat pengaturan terakhir + catatan lama AC menyala (dipakai Activity, Widget, Timer). */
object AcStore {
    private fun p(c: Context) = c.getSharedPreferences("ac", Context.MODE_PRIVATE)
    private fun key(t: Long) = "d_" + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(t))

    private fun dayStart(t: Long, back: Int = 0): Long = Calendar.getInstance().apply {
        timeInMillis = t
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        add(Calendar.DAY_OF_YEAR, -back)
    }.timeInMillis

    fun load(c: Context): AcState {
        val d = AcState()
        val sp = p(c)
        return AcState(
            on = sp.getBoolean("on", d.on),
            temp = sp.getInt("temp", d.temp).coerceIn(16, 30),
            mode = sp.getInt("mode", d.mode),
            fan = sp.getInt("fan", d.fan),
            swing = sp.getBoolean("swing", d.swing),
            freq = sp.getInt("freq", d.freq),
            timerEnd = sp.getLong("timerEnd", 0L)
        )
    }

    fun save(c: Context, s: AcState) {
        val sp = p(c)
        val was = sp.getBoolean("on", false)
        val now = System.currentTimeMillis()
        val ed = sp.edit()
        ed.putBoolean("on", s.on).putInt("temp", s.temp).putInt("mode", s.mode)
            .putInt("fan", s.fan).putBoolean("swing", s.swing).putInt("freq", s.freq)
            .putLong("timerEnd", s.timerEnd)
        if (!was && s.on) ed.putLong("onSince", now)
        if (was && !s.on) {
            addUsage(sp, ed, sp.getLong("onSince", 0L), now)
            ed.putLong("onSince", 0L)
        }
        ed.apply()
    }

    /** Catat sesi menyala per hari (dipecah di tengah malam). */
    private fun addUsage(sp: SharedPreferences, ed: SharedPreferences.Editor, start: Long, end: Long) {
        if (start <= 0L || end <= start) return
        var t = start
        while (t < end) {
            val next = dayStart(t, -1)
            val seg = minOf(end, next) - t
            val k = key(t)
            ed.putLong(k, sp.getLong(k, 0L) + seg)
            t += seg
        }
    }

    /** Total lama menyala (ms) dalam [days] hari terakhir, termasuk sesi yang sedang berjalan. */
    fun usageMs(c: Context, days: Int): Long {
        val sp = p(c)
        val now = System.currentTimeMillis()
        var sum = 0L
        for (i in 0 until days) sum += sp.getLong(key(dayStart(now, i)), 0L)
        val since = sp.getLong("onSince", 0L)
        if (sp.getBoolean("on", false) && since > 0L) sum += now - maxOf(since, dayStart(now, days - 1))
        return sum
    }

    fun costCfg(c: Context): CostCfg {
        val sp = p(c); val d = CostCfg()
        return CostCfg(
            sp.getFloat("watt", d.watt.toFloat()).toDouble(),
            sp.getFloat("tarif", d.tarif.toFloat()).toDouble(),
            sp.getFloat("duty", d.duty.toFloat()).toDouble()
        )
    }

    fun saveCostCfg(c: Context, g: CostCfg) {
        p(c).edit().putFloat("watt", g.watt.coerceIn(100.0, 5000.0).toFloat())
            .putFloat("tarif", g.tarif.coerceIn(0.0, 10000.0).toFloat())
            .putFloat("duty", g.duty.coerceIn(10.0, 100.0).toFloat()).apply()
    }
}
