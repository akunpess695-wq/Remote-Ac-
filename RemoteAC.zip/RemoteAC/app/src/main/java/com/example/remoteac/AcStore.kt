package com.example.remoteac

import android.content.Context

data class AcState(
    val on: Boolean = false,
    val temp: Int = 25,
    val mode: Int = PanasonicAc.COOL,
    val fan: Int = PanasonicAc.FAN_AUTO,
    val swing: Boolean = false,
    val freq: Int = PanasonicAc.FREQ_DEFAULT,
    val timerEnd: Long = 0L
)

/** Simpan/muat pengaturan terakhir (dipakai Activity, Widget, dan Timer). */
object AcStore {
    private fun p(c: Context) = c.getSharedPreferences("ac", Context.MODE_PRIVATE)

    fun load(c: Context): AcState {
        val d = AcState()
        val sp = p(c)
        return AcState(
            on = sp.getBoolean("on", d.on),
            temp = sp.getInt("temp", d.temp).coerceIn(16, 30),
            mode = sp.getInt("mode", d.mode),
            fan = sp.getInt("fan", d.fan),
            swing = sp.getBoolean("swing", d.swing),
            freq = sp.getInt("freq", d.freq),
            timerEnd = sp.getLong("timerEnd", 0L)
        )
    }

    fun save(c: Context, s: AcState) {
        p(c).edit()
            .putBoolean("on", s.on).putInt("temp", s.temp).putInt("mode", s.mode)
            .putInt("fan", s.fan).putBoolean("swing", s.swing).putInt("freq", s.freq)
            .putLong("timerEnd", s.timerEnd).apply()
    }
}
