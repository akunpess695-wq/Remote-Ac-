package com.example.remoteac

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class AcState(
    val on: Boolean = false,
    val temp: Int = 25,
    val mode: Int = PanasonicAc.COOL,
    val fan: Int = PanasonicAc.FAN_AUTO,
    val swing: Boolean = false,
    val freq: Int = PanasonicAc.FREQ_DEFAULT,
    val timerEnd: Long = 0L
)

/** Pengaturan perkiraan listrik: daya AC (watt), tarif (Rp/kWh), faktor kompresor (%). */
data class CostCfg(val watt: Double = 760.0, val tarif: Double = 1444.7, val duty: Double = 70.0) {
    fun kwh(ms: Long) = ms / 3_600_000.0 * watt / 1000.0 * duty / 100.0
    fun rupiah(ms: Long) = kwh(ms) * tarif
}

/** Float -> Double tanpa noise biner (1444.7f jadi 1444.7, bukan 1444.699951171875). */
internal fun f2d(f: Float): Double = f.toString().toDouble()

/** Simpan/muat pengaturan terakhir + catatan lama AC menyala (dipakai Activity, Widget, Timer). */
object AcStore {
    private fun p(c: Context) = c.getSharedPreferences("ac", Context.MODE_PRIVATE)
    internal fun rawPrefs(c: Context) = p(c)
    private fun key(t: Long) = "d_" + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(t))

    private fun dayStart(t: Long, back: Int = 0): Long = Calendar.getInstance().apply {
        timeInMillis = t
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        add(Calendar.DAY_OF_YEAR, -back)
    }.timeInMillis

    fun load(c: Context): AcState {
        val d = AcState()
        val sp = p(c)
        return AcState(
            on = sp.getBoolean("on", d.on),
            temp = sp.getInt("temp", d.temp).coerceIn(16, 30),
            mode = sp.getInt("mode", d.mode),
            fan = sp.getInt("fan", d.fan),
            swing = sp.getBoolean("swing", d.swing),
            freq = sp.getInt("freq", d.freq),
            timerEnd = sp.getLong("timerEnd", 0L)
        )
    }

    fun save(c: Context, s: AcState) {
        val sp = p(c)
        val was = sp.getBoolean("on", false)
        val now = System.currentTimeMillis()
        val ed = sp.edit()
        ed.putBoolean("on", s.on).putInt("temp", s.temp).putInt("mode", s.mode)
            .putInt("fan", s.fan).putBoolean("swing", s.swing).putInt("freq", s.freq)
            .putLong("timerEnd", s.timerEnd)
        if (!was && s.on) ed.putLong("onSince", now)
        if (was && !s.on) {
            addUsage(sp, ed, sp.getLong("onSince", 0L), now)
            ed.putLong("onSince", 0L)
        }
        ed.apply()
    }

    /** Catat sesi menyala per hari (dipecah di tengah malam). */
    private fun addUsage(sp: SharedPreferences, ed: SharedPreferences.Editor, start: Long, end: Long) {
        if (start <= 0L || end <= start) return
        ed.putLong("total", sp.getLong("total", 0L) + (end - start))
        var t = start
        while (t < end) {
            val next = dayStart(t, -1)
            val seg = minOf(end, next) - t
            val k = key(t)
            ed.putLong(k, sp.getLong(k, 0L) + seg)
            t += seg
        }
    }

    /** Total lama menyala (ms) dalam [days] hari terakhir, termasuk sesi yang sedang berjalan. */
    fun usageMs(c: Context, days: Int): Long {
        val sp = p(c)
        val now = System.currentTimeMillis()
        var sum = 0L
        for (i in 0 until days) sum += sp.getLong(key(dayStart(now, i)), 0L)
        val since = sp.getLong("onSince", 0L)
        if (sp.getBoolean("on", false) && since > 0L) sum += now - maxOf(since, dayStart(now, days - 1))
        return sum
    }

    fun costCfg(c: Context): CostCfg {
        val sp = p(c); val d = CostCfg()
        return CostCfg(
            f2d(sp.getFloat("watt", d.watt.toFloat())),
            f2d(sp.getFloat("tarif", d.tarif.toFloat())),
            f2d(sp.getFloat("duty", d.duty.toFloat()))
        )
    }

    fun saveCostCfg(c: Context, g: CostCfg) {
        p(c).edit().putFloat("watt", g.watt.coerceIn(100.0, 5000.0).toFloat())
            .putFloat("tarif", g.tarif.coerceIn(0.0, 10000.0).toFloat())
            .putFloat("duty", g.duty.coerceIn(10.0, 100.0).toFloat()).apply()
    }

    /** Total lama AC menyala sejak app dipakai (ms), termasuk sesi yang sedang berjalan. */
    fun totalMs(c: Context): Long {
        val sp = p(c)
        val since = sp.getLong("onSince", 0L)
        val running = if (sp.getBoolean("on", false) && since > 0L) System.currentTimeMillis() - since else 0L
        return sp.getLong("total", 0L) + running
    }

    fun tokenCfg(c: Context): TokenCfg {
        val sp = p(c); val d = TokenCfg()
        return TokenCfg(
            f2d(sp.getFloat("tk_balance", d.balanceKwh.toFloat())),
            sp.getLong("tk_at", 0L),
            sp.getLong("tk_base", 0L),
            f2d(sp.getFloat("tk_other", d.otherKwhPerDay.toFloat())),
            sp.getInt("tk_warn", d.warnDays)
        )
    }

    /** Catat saldo token (kWh) sekarang; pemakaian dihitung dari titik ini. */
    fun saveToken(c: Context, balanceKwh: Double, otherKwhPerDay: Double, warnDays: Int) {
        p(c).edit()
            .putFloat("tk_balance", balanceKwh.coerceIn(0.0, 100_000.0).toFloat())
            .putLong("tk_at", System.currentTimeMillis())
            .putLong("tk_base", totalMs(c))
            .putFloat("tk_other", otherKwhPerDay.coerceIn(0.0, 1_000.0).toFloat())
            .putInt("tk_warn", warnDays.coerceIn(1, 30))
            .apply()
    }

    fun tokenNotifiedDay(c: Context): String? = p(c).getString("tk_notified", null)
    fun setTokenNotifiedDay(c: Context, day: String) { p(c).edit().putString("tk_notified", day).apply() }

    /** Perkiraan sisa token sekarang, atau null jika belum diatur. */
    fun tokenEstimate(c: Context): TokenCalc.Estimate? {
        val t = tokenCfg(c)
        if (!t.active) return null
        val cost = costCfg(c)
        val now = System.currentTimeMillis()
        val acSince = cost.kwh((totalMs(c) - t.baseMs).coerceAtLeast(0L))
        val acPerDay = cost.kwh(usageMs(c, 7)) / 7.0
        return TokenCalc.estimate(t.balanceKwh, now - t.setAt, acSince, t.otherKwhPerDay, acPerDay, t.warnDays)
    }
}
