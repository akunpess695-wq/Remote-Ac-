package com.example.remoteac

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.remoteac.databinding.ActivitySettingsBinding
import java.text.NumberFormat
import java.util.Locale

/** Pengaturan: perkiraan listrik + carrier IR (disembunyikan dari layar utama). */
class SettingsActivity : AppCompatActivity() {
    private lateinit var b: ActivitySettingsBinding

    private fun fmt(v: Double) = if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(b.root)
        EdgeToEdge.apply(this, b.root)

        val g = AcStore.costCfg(this)
        b.etWatt.setText(fmt(g.watt))
        b.etTarif.setText(fmt(g.tarif))
        b.etDuty.setText(fmt(g.duty))

        b.btnBack.setOnClickListener { finish() }
        b.btnSave.setOnClickListener {
            val cur = AcStore.costCfg(this)
            AcStore.saveCostCfg(this, CostCfg(
                b.etWatt.text.toString().toDoubleOrNull() ?: cur.watt,
                b.etTarif.text.toString().toDoubleOrNull() ?: cur.tarif,
                b.etDuty.text.toString().toDoubleOrNull() ?: cur.duty
            ))
            renderCost()
            Toast.makeText(this, "Tersimpan", Toast.LENGTH_SHORT).show()
        }

        b.swCarrier.isChecked = AcStore.load(this).freq == PanasonicAc.FREQ_ALT
        b.swCarrier.setOnCheckedChangeListener { _, on ->
            val f = if (on) PanasonicAc.FREQ_ALT else PanasonicAc.FREQ_DEFAULT
            AcStore.save(this, AcStore.load(this).copy(freq = f))
        }
    }

    override fun onResume() { super.onResume(); renderCost() }

    private fun renderCost() {
        val g = AcStore.costCfg(this)
        val nf = NumberFormat.getInstance(Locale("id", "ID"))
        fun line(label: String, days: Int): String {
            val ms = AcStore.usageMs(this, days)
            val m = ms / 60_000
            return "$label: ${m / 60} j ${m % 60} m  •  ±${"%.1f".format(g.kwh(ms))} kWh  •  ±Rp${nf.format(Math.round(g.rupiah(ms)))}"
        }
        b.tvCost.text = line("Hari ini", 1) + "\n" + line("30 hari terakhir", 30)
    }
}
