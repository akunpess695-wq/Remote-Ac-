package com.example.remoteac

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.remoteac.databinding.ActivitySettingsBinding
import java.text.NumberFormat
import java.util.Locale

/** Pengaturan: perkiraan listrik + carrier IR (disembunyikan dari layar utama). */
class SettingsActivity : AppCompatActivity() {
    private lateinit var b: ActivitySettingsBinding

    private val askNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (!ok) Toast.makeText(this, "Tanpa izin notifikasi, peringatan hanya tampil di app", Toast.LENGTH_LONG).show()
    }

    private fun fmt(v: Double) = if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(b.root)
        EdgeToEdge.apply(this, b.root)

        val g = AcStore.costCfg(this)
        b.etWatt.setText(fmt(g.watt))
        b.etTarif.setText(fmt(g.tarif))
        b.etDuty.setText(fmt(g.duty))

        b.btnBack.setOnClickListener { finish() }
        b.btnSave.setOnClickListener {
            val cur = AcStore.costCfg(this)
            AcStore.saveCostCfg(this, CostCfg(
                b.etWatt.text.toString().toDoubleOrNull() ?: cur.watt,
                b.etTarif.text.toString().toDoubleOrNull() ?: cur.tarif,
                b.etDuty.text.toString().toDoubleOrNull() ?: cur.duty
            ))
            renderCost()
            Toast.makeText(this, "Tersimpan", Toast.LENGTH_SHORT).show()
        }

        val tk = AcStore.tokenCfg(this)
        AcStore.tokenEstimate(this)?.let { b.etBalance.setText(fmt(Math.round(it.remainingKwh * 10) / 10.0)) }
        if (tk.active) b.etOther.setText(fmt(tk.otherKwhPerDay))
        b.etWarn.setText(tk.warnDays.toString())
        b.btnTokenSave.setOnClickListener {
            val bal = b.etBalance.text.toString().toDoubleOrNull()
            if (bal == null || bal < 0) {
                Toast.makeText(this, "Isi sisa token (kWh) dulu", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            AcStore.saveToken(
                this, bal,
                b.etOther.text.toString().toDoubleOrNull() ?: 0.0,
                b.etWarn.text.toString().toIntOrNull() ?: 3
            )
            TokenNotifier.schedule(this)
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
            renderToken()
            Toast.makeText(this, "Saldo token tersimpan", Toast.LENGTH_SHORT).show()
        }

        b.btnExport.setOnClickListener {
            val text = DataBackup.encode(AcStore.rawPrefs(this).all)
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("Remote AC", text))
            Toast.makeText(this, "Data disalin. Simpan di tempat aman (mis. kirim ke chat sendiri).", Toast.LENGTH_LONG).show()
            startActivity(Intent.createChooser(
                Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text),
                "Kirim data ke..."
            ))
        }
        b.btnImport.setOnClickListener {
            val clip = (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).primaryClip
            val text = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this).toString() else null
            val items = DataBackup.decode(text)
            if (items == null) {
                Toast.makeText(this, "Clipboard tidak berisi data cadangan Remote AC. Salin dulu teks cadangannya.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            AlertDialog.Builder(this)
                .setTitle("Pulihkan data?")
                .setMessage("Riwayat pemakaian dan saldo token saat ini akan diganti dengan data cadangan (${items.size} entri).")
                .setPositiveButton("Pulihkan") { _, _ ->
                    DataBackup.apply(this, items)
                    TokenNotifier.schedule(this)
                    Toast.makeText(this, "Data dipulihkan", Toast.LENGTH_SHORT).show()
                    recreate()
                }
                .setNegativeButton("Batal", null)
                .show()
        }

        b.swCarrier.isChecked = AcStore.load(this).freq == PanasonicAc.FREQ_ALT
        b.swCarrier.setOnCheckedChangeListener { _, on ->
            val f = if (on) PanasonicAc.FREQ_ALT else PanasonicAc.FREQ_DEFAULT
            AcStore.save(this, AcStore.load(this).copy(freq = f))
        }
    }

    override fun onResume() { super.onResume(); renderCost(); renderToken() }

    private fun renderCost() {
        val g = AcStore.costCfg(this)
        val nf = NumberFormat.getInstance(Locale("id", "ID"))
        fun line(label: String, days: Int): String {
            val ms = AcStore.usageMs(this, days)
            val m = ms / 60_000
            return "$label: ${m / 60} j ${m % 60} m  •  ±${"%.1f".format(g.kwh(ms))} kWh  •  ±Rp${nf.format(Math.round(g.rupiah(ms)))}"
        }
        b.tvCost.text = line("Hari ini", 1) + "\n" + line("30 hari terakhir", 30)
    }

    private fun renderToken() {
        val t = AcStore.tokenEstimate(this)
        if (t == null) {
            b.tvToken.text = "Belum diatur. Isi sisa token di meter lalu tekan Simpan."
            return
        }
        val g = AcStore.costCfg(this)
        val nf = NumberFormat.getInstance(Locale("id", "ID"))
        b.tvToken.text = (if (t.warn) "⚠ " else "") + "Sisa ±${"%.1f".format(t.remainingKwh)} kWh " +
            "(±Rp${nf.format(Math.round(t.remainingKwh * g.tarif))})\n" +
            "Habis ${TokenCalc.daysText(t.daysLeft)}  •  ±${"%.1f".format(t.perDayKwh)} kWh/hari"
    }
}
