package com.example.remoteac

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class AcWidget : AppWidgetProvider() {

    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        ids.forEach { m.updateAppWidget(it, views(c)) }
    }

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        val s = AcStore.load(c)
        val n = when (i.action) {
            ACT_POWER -> s.copy(on = !s.on)
            ACT_PLUS -> s.copy(temp = (s.temp + 1).coerceAtMost(30), on = true)
            ACT_MINUS -> s.copy(temp = (s.temp - 1).coerceAtLeast(16), on = true)
            else -> return
        }
        AcStore.save(c, n)
        IrSender.send(c, n)
        refresh(c)
    }

    companion object {
        private const val ACT_POWER = "com.example.remoteac.POWER"
        private const val ACT_PLUS = "com.example.remoteac.PLUS"
        private const val ACT_MINUS = "com.example.remoteac.MINUS"

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, AcWidget::class.java))
            ids.forEach { m.updateAppWidget(it, views(c)) }
            AcTile.refresh(c)
        }

        private fun pi(c: Context, act: String) = PendingIntent.getBroadcast(
            c, act.hashCode(), Intent(c, AcWidget::class.java).setAction(act),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        private fun views(c: Context): RemoteViews {
            val s = AcStore.load(c)
            return RemoteViews(c.packageName, R.layout.widget).apply {
                setTextViewText(R.id.wTemp, "${s.temp}°" + if (s.on) " ON" else " OFF")
                setOnClickPendingIntent(R.id.wPower, pi(c, ACT_POWER))
                setOnClickPendingIntent(R.id.wPlus, pi(c, ACT_PLUS))
                setOnClickPendingIntent(R.id.wMinus, pi(c, ACT_MINUS))
            }
        }
    }
}
