package com.example.remoteac

/** Pengaturan pelacak token: saldo kWh saat dicatat, waktu catat, dan pemakaian rumah selain AC. */
data class TokenCfg(
    val balanceKwh: Double = 0.0,
    val setAt: Long = 0L,
    val baseMs: Long = 0L,      // total lama AC menyala saat saldo dicatat
    val otherKwhPerDay: Double = 0.0,
    val warnDays: Int = 3
) {
    val active get() = setAt > 0L
}

object TokenCalc {
    const val DAY_MS = 86_400_000.0

    data class Estimate(
        val remainingKwh: Double,
        val daysLeft: Double?,
        val perDayKwh: Double,
        val warn: Boolean
    )

    /**
     * Sisa = saldo - pemakaian rumah lain sejak dicatat - pemakaian AC sejak dicatat.
     * Laju harian = pemakaian rumah lain + rata-rata AC 7 hari terakhir.
     */
    fun estimate(
        balance: Double, elapsedMs: Long, acKwhSince: Double,
        otherPerDay: Double, acKwhPerDay: Double, warnDays: Int
    ): Estimate {
        val days = elapsedMs.coerceAtLeast(0L) / DAY_MS
        val remaining = (balance - otherPerDay * days - acKwhSince).coerceAtLeast(0.0)
        val perDay = otherPerDay + acKwhPerDay
        val left = if (perDay > 0.0) remaining / perDay else null
        return Estimate(remaining, left, perDay, left != null && left <= warnDays)
    }

    fun daysText(d: Double?): String = when {
        d == null -> "belum bisa diperkirakan"
        d < 1.0 -> "kurang dari 1 hari lagi"
        else -> "±${d.toInt()} hari lagi"
    }
}
